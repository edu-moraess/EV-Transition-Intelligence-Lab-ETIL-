# EVQTI — nota de proveniência dos artefatos

Data da reprodução: 2026-11-27

Os arquivos:
- EVQTI_WALK_FORWARD_MAIN_75e43af.csv
- EVQTI_WALK_FORWARD_SUMMARY_75e43af.json

foram reproduzidos nesta data, pois os arquivos originais não estavam
disponíveis no runtime nem no Google Drive pesquisado.

Checkout validado:
- Branch: main
- Commit: 75e43af68f87d449bf83436976e856144059b4e6
- Dataset: IEA 2026, Historical, Cars
- Painel: 60 países, 760 observações
- Parâmetros: train_years=6, test_years=1, step=1, min_countries=10
- Mean Rank IC reproduzido: 0.31307994985200316
- Janelas positivas: 9/9
- Janelas com p nominal < 0.05: 4/9

Status: reprodução numérica validada; não recuperação dos arquivos originais.
